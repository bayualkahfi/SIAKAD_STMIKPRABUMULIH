-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 02 Okt 2018 pada 08.12
-- Versi Server: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stmikypp_akademik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_level` int(1) NOT NULL DEFAULT '1',
  `username` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `keterangan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `telepon` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_foto.jpg',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`ID`, `id_level`, `username`, `password`, `keterangan`, `nama_lengkap`, `email`, `telepon`, `foto`, `aktif`) VALUES
(4, 1, 'admin', 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec', '', 'admin', '', '', 'Untitled-1.png', 'Y'),
(5, 1, 'prodipai', 'e959ff21b941dd9ca11a4db2add4fa61cb7c2df7a8f03b7c4ca2466b05b5f4899574ef5b1e880812da3ace98d0beacb1419c6c7ebda7169aabc3b1fb0f92f04e', 'Ketua Prodi PAI', 'Drs.Lili Sadeli, M.Pd.I', '', '', '', 'Y'),
(6, 1, 'prodieksya', '1c491c214a0b0778a0fee8f8e0e4651d97ffa06cc1dfcf0563844876867a879ee9f76b67051caa8ed73873ddfac66b2c1ecea69357e584af4a9d216de50a43af', 'Ketua Prodi Ekonomi Syariah', 'H. Agus Hermawan, M.Ag.', '', '', '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `agama`
--

CREATE TABLE IF NOT EXISTS `agama` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `agama`
--

INSERT INTO `agama` (`ID`, `nama`, `aktif`) VALUES
(1, 'ISLAM', 'Y'),
(2, 'KRISTEN KATOLIK', 'Y'),
(3, 'KRISTEN PROTESTAN', 'Y'),
(4, 'BUDHA', 'Y'),
(5, 'HINDU', 'Y'),
(6, 'LAIN-LAIN', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `akademik`
--

CREATE TABLE IF NOT EXISTS `akademik` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_level` int(2) NOT NULL DEFAULT '3',
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `username` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `keterangan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `telepon` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `alamat` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_foto.jpg',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `akademik`
--

INSERT INTO `akademik` (`ID`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `username`, `password`, `nama_lengkap`, `keterangan`, `email`, `telepon`, `alamat`, `foto`, `aktif`) VALUES
(1, 3, 100, 461, 'STMIKSI', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', 'Sistem Informasi', '', '', '', '', 'no_foto.jpg', 'Y'),
(2, 3, 100, 460, 'STMIKKA', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', 'Komputer Akuntansi', '', '', '', '', 'no_foto.jpg', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `beritaawal`
--

CREATE TABLE IF NOT EXISTS `beritaawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `isi` text COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `beritaawal`
--

INSERT INTO `beritaawal` (`id`, `tanggal`, `isi`, `gambar`, `aktif`) VALUES
(1, '2015-07-16', 'Pembuatan Aplikasi Sistem Informasi Akademik Kampus ini bertujuan sebagai bahan pembelajaran bagi para programmer di indonesia baik tingkat pemula, menegah,maupun mahir, sehingga dengan hadirnya pembelajaran ini kedepannya para programmer dapat membuat berbagai aplikasi lainnya dengan memahami konsep sederhana yang penulis sajikan ini \r\n\r\ndan didalam praktek pembuatan aplikasi tersebut jika para programmer sulit memahami jalannya program untuk segera merujuk kepada buku yang telah diterbitkan\r\n\r\n', 'icon.png', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dosen`
--

CREATE TABLE IF NOT EXISTS `dosen` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `id_level` int(1) NOT NULL DEFAULT '2',
  `username` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `NIDN` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `InstitusiInduk` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Homebase` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TempatLahir` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `KTP` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Agama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` text COLLATE latin1_general_ci,
  `Email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Handphone` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Keterangan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Propinsi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Negara` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Gelar` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Jenjang_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Keilmuan` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Kelamin_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Jabatan_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JabatanDikti_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `TglBekerja` date NOT NULL,
  `StatusDosen_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusKerja_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci DEFAULT 'no foto.jpg',
  PRIMARY KEY (`ID`),
  KEY `username` (`username`),
  KEY `NIDN` (`NIDN`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=48 ;

--
-- Dumping data untuk tabel `dosen`
--

INSERT INTO `dosen` (`ID`, `id_level`, `username`, `password`, `NIDN`, `nama_lengkap`, `Identitas_ID`, `Jurusan_ID`, `InstitusiInduk`, `Homebase`, `TempatLahir`, `TanggalLahir`, `KTP`, `Agama`, `Alamat`, `Email`, `Telepon`, `Handphone`, `Keterangan`, `Kota`, `Propinsi`, `Negara`, `Gelar`, `Jenjang_ID`, `Keilmuan`, `Kelamin_ID`, `Jabatan_ID`, `JabatanDikti_ID`, `TglBekerja`, `StatusDosen_ID`, `StatusKerja_ID`, `Aktif`, `foto`) VALUES
(32, 2, 'STMIK01', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Ariansyah,', 100, '461,460', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', '', '', '', '', 'S.Kom., M.Kom', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(30, 2, 'STMIK30', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Iwan Setiawan', 100, '461,460', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', '', '', '', '', 'S.Kom., M.Kom', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(29, 2, 'STMIK29', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Anyuger Dislamic, S. Kom., M. Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(28, 2, 'STMIK28', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Nurmayanti, S. Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(27, 2, 'STMIK27', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Fajriyah, S.Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(26, 2, 'STMIK26', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Phinton Panglipur, S.T.,M.Kom', 100, '461,460', '', '', '', '0000-00-00', '', '0', '', '', '', '', '', '', '', '', '', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(25, 2, 'STMIK25', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Khana Wijaya, S.Kom., M.Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(24, 2, 'STMIK24', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Rahma Diana, S. Kom., M. Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(23, 2, 'STMIK23', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Rishi Suparianto, SH., M. Hum', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(21, 2, 'STMIK21', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Syelly Ekapermatasari, S.Pd', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(19, 2, 'STMIK19', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'A. Barnianto, S.E., M.Si', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(12, 2, 'STMIK12', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Yuntari Purbasari, S. Kom., M.Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(13, 2, 'STMIK13', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Zakaria Harahap, SE., M. Hi', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(11, 2, 'STMIK11', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Nur Aini Hutagalung, S. Kom.,M. Si', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(10, 2, 'STMIK10', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Ahmad Barnianto, SE., M. Si', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(8, 2, 'STMIK08', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Suhartini, S. Kom., M. Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(9, 2, 'STMIK09', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Anita Bayu, ST., M. Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(7, 2, 'STMIK07', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Yeni Yuliana, S.sos.i.,Mpd.i', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(6, 2, 'STMIK06', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Hepny samosir, S.Pd.,M.Pd', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(5, 2, 'STMIK05', '579422299af7e968623e0e38bf443ff135af06eab6485ffcc725c1f1649ce02927fd1c59cba3b35522611c25b14dbb848f523679d914d8cbd2454d98591c692f', '0216088301', 'Andi Christian', 100, '461', '023066', '021', 'Prabumulih', '1983-08-16', '', 'ISLAM', '', 'andichristian_cdm@yahoo.com', '', '081211606764', '', '', '', '', 'S.Kom., M.Kom', 'B', 'Komputer', '', 'B', '02', '2011-04-04', '0', 'A', 'Y', 'no foto.jpg'),
(4, 2, 'STMIK04', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Muchlis,S.Kom., M.Si', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(3, 2, 'STMIK03', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Sebri Hesinto, SE.,M.Si', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg'),
(2, 2, 'STMIK01', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '', 'Ahmat Josi, S.kom.,M.Kom', 100, '461,460', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', 'Y', 'no foto.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dropdownsystem`
--

CREATE TABLE IF NOT EXISTS `dropdownsystem` (
  `ID_ds` int(11) NOT NULL AUTO_INCREMENT,
  `id_group` int(11) NOT NULL,
  `nama` varchar(100) CHARACTER SET latin1 NOT NULL,
  `menu_order` int(11) NOT NULL,
  `url` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID_ds`),
  KEY `id_group` (`id_group`,`menu_order`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=47 ;

--
-- Dumping data untuk tabel `dropdownsystem`
--

INSERT INTO `dropdownsystem` (`ID_ds`, `id_group`, `nama`, `menu_order`, `url`) VALUES
(1, 2, '01 Kalender Akademik', 1, '?page=kalenderakademik'),
(2, 2, '02 Penjadwalan Kuliah', 2, '?page=jadwalkuliah'),
(3, 2, '03 Registrasi Ulang Mahasiswa', 3, '?page=registrasiulangmhsw'),
(4, 4, '01 Absen Kuliah', 1, '?page=dosenabsenkuliah'),
(5, 4, '02 Nilai Mahasiswa', 2, '?page=dosennilaimahasiswa'),
(6, 2, '04 KRS Mahasiswa', 4, '?page=akademikkrs'),
(7, 2, '05 Input Nilai Mahasiswa', 5, '?page=akademikinputnilaimhs'),
(8, 2, '06 KHS Mahasiswa', 6, '?page=akademikkhsmhs'),
(9, 2, '07 Transkrip Nilai Mahasiswa', 7, '?page=akademiktranskripnilai'),
(10, 8, '01 Identitas Institusi', 1, '?page=masterinstitusi'),
(11, 8, '02 Program Studi', 2, '?page=masterprodi'),
(12, 8, '03 Program', 3, '?page=masterprogram'),
(13, 8, '04 Kampus', 4, '?page=masterkampus'),
(14, 8, '05 Ruangan', 5, '?page=masterruangan'),
(15, 8, '06 Matakuliah', 6, '?page=mastermatakuliah'),
(16, 8, '07 Dosen', 7, '?page=masterdosen'),
(17, 8, '08 Mahasiswa', 8, '?page=mastermahasiswa'),
(18, 10, '01 Admin Administrator', 1, '?page=adminadministrator'),
(19, 10, '02 Admin Akademik', 2, '?page=adminakademik'),
(21, 57, '01 MSMHS', 1, '?page=epsbedmsmhs'),
(22, 57, '02 TBKMK', 2, '?page=epsbedttbkmk'),
(23, 57, '03 TBBNL', 3, '?page=epsbedtbbnl'),
(24, 57, '04 TRAKD', 4, '?page=epsbedtrakd'),
(25, 57, '05 TRNLM', 5, '?page=epsbedtrnlm'),
(26, 1, '01 Kalender Akademik', 1, '?page=baakademikkalender'),
(27, 1, '02 Penjadwalan Kuliah', 2, '?page=baakademikjadwal'),
(28, 1, '03 Registrasi Ulang Mahasiswa', 3, '?page=baakademikregulang'),
(29, 1, '04 KRS Mahasiswa', 4, '?page=baakademikjadwalkrs'),
(30, 1, '05 Input Nilai Mahasiswa', 5, '?page=bakademikinputnilaimhs'),
(31, 1, '06 KHS Mahasiswa', 6, '?page=bakademikkhsmhs'),
(32, 1, '07 Transkrip Nilai Mahasiswa', 7, '?page=bakademiktranskripnilai'),
(33, 8, '01 Matakuliah', 1, '?page=baakademikmastermatakuliah'),
(34, 8, '02 Mahasiswa', 2, '?page=baakademikmastermahasiswa'),
(35, 4, '01 Data Dosen', 1, '?page=dosendata'),
(36, 4, '02 Input Nilai Mahasiswa', 2, '?page=doseninputnilaimhsw'),
(37, 7, '01 Data Mahasiswa', 1, '?page=mahasiswadata'),
(38, 7, '02 KRS Mahasiswa', 2, '?page=mahasiswakrs'),
(40, 7, '03 KHS Mahasiswa', 3, '?page=mahasiswakhs'),
(41, 7, '04 Transkrip Nilai', 4, '?page=mahasiswatranskrip'),
(45, 4, '03 Upload Materi', 3, '?page=1f56234e-4361-4706-bb5a-91d3101bbdb6'),
(44, 59, '01 Download', 1, '?page=50f9e899-0d4d-4b7b-a518-fb18bc430926'),
(46, 7, '05 Download Materi', 5, '?page=24fd7148-9843-46d6-bb33-5b1d86b5a172');

-- --------------------------------------------------------

--
-- Struktur dari tabel `epsbed`
--

CREATE TABLE IF NOT EXISTS `epsbed` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Ket` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=20 ;

--
-- Dumping data untuk tabel `epsbed`
--

INSERT INTO `epsbed` (`ID`, `Nama`, `Ket`) VALUES
(15, 'TBKMK_20152.DBF', 'tbkmk'),
(16, 'TBBNL_20152.DBF', 'tbbnl'),
(19, 'MSMHS_20151.DBF', 'msmhs');

-- --------------------------------------------------------

--
-- Struktur dari tabel `error`
--

CREATE TABLE IF NOT EXISTS `error` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tabel` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `text` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `error`
--

INSERT INTO `error` (`id`, `tabel`, `text`) VALUES
(1, 'Group Modul', '1. Pengisian form berurutan sesuai dengan parent ID modul.2. Jika Terjadi Kesalahan yang tidak anda ketahui silakan hubungi administrator anda.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fileupload`
--

CREATE TABLE IF NOT EXISTS `fileupload` (
  `File_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama_File` varchar(255) NOT NULL,
  `File` varchar(100) NOT NULL,
  `Level_ID` int(11) NOT NULL,
  `Uplouder` varchar(100) NOT NULL,
  `TglInput` datetime NOT NULL,
  PRIMARY KEY (`File_ID`),
  KEY `File_ID` (`File_ID`),
  KEY `Level_ID` (`Level_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data untuk tabel `fileupload`
--

INSERT INTO `fileupload` (`File_ID`, `Nama_File`, `File`, `Level_ID`, `Uplouder`, `TglInput`) VALUES
(18, 'Kalender Akademik Semt. Genap 2015_2016', 'Kalender Akademi k Semester Genap 20152016.pdf', 1, '', '2016-02-05 23:32:11'),
(17, 'Materi Pengantar Komputer', '', 2, '066', '2016-02-04 10:58:13'),
(19, 'rpl', 'PRODI SI OSPEK.pptx', 2, 'STMIK05', '2018-10-01 13:09:36');

-- --------------------------------------------------------

--
-- Struktur dari tabel `groupmodul`
--

CREATE TABLE IF NOT EXISTS `groupmodul` (
  `id_group` int(10) NOT NULL AUTO_INCREMENT,
  `relasi_modul` int(10) NOT NULL,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_group`),
  KEY `relasi_modul` (`relasi_modul`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=60 ;

--
-- Dumping data untuk tabel `groupmodul`
--

INSERT INTO `groupmodul` (`id_group`, `relasi_modul`, `nama`) VALUES
(1, 1, 'Ba Akademik'),
(2, 2, 'Akademik'),
(4, 4, 'Dosen'),
(7, 7, 'Mahasiswa'),
(8, 8, 'Master'),
(10, 10, 'Admin'),
(57, 12, 'EPSBED'),
(59, 11, 'Download');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hakmodul`
--

CREATE TABLE IF NOT EXISTS `hakmodul` (
  `ID_hm` int(11) NOT NULL AUTO_INCREMENT,
  `id_level` int(11) NOT NULL,
  `ID_ds` int(11) NOT NULL,
  PRIMARY KEY (`ID_hm`),
  KEY `ID_ds` (`ID_ds`,`id_level`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=45 ;

--
-- Dumping data untuk tabel `hakmodul`
--

INSERT INTO `hakmodul` (`ID_hm`, `id_level`, `ID_ds`) VALUES
(1, 1, 1),
(2, 1, 2),
(15, 1, 16),
(4, 1, 3),
(5, 1, 6),
(6, 1, 7),
(7, 1, 8),
(8, 1, 9),
(9, 1, 10),
(10, 1, 11),
(11, 1, 12),
(12, 1, 13),
(13, 1, 14),
(14, 1, 15),
(16, 1, 17),
(17, 1, 18),
(18, 1, 19),
(19, 1, 20),
(20, 1, 21),
(21, 1, 22),
(22, 1, 23),
(23, 1, 24),
(24, 1, 25),
(25, 3, 26),
(26, 3, 27),
(27, 3, 28),
(28, 3, 29),
(29, 3, 30),
(30, 3, 31),
(31, 3, 32),
(32, 3, 33),
(33, 3, 34),
(34, 2, 35),
(35, 2, 36),
(36, 4, 37),
(37, 4, 38),
(38, 4, 39),
(39, 4, 40),
(40, 4, 41),
(42, 1, 44),
(43, 2, 45),
(44, 4, 46);

-- --------------------------------------------------------

--
-- Struktur dari tabel `hari`
--

CREATE TABLE IF NOT EXISTS `hari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `hari`
--

INSERT INTO `hari` (`id`, `hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jumat'),
(6, 'Sabtu'),
(7, 'Minggu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hidup`
--

CREATE TABLE IF NOT EXISTS `hidup` (
  `Hidup` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`Hidup`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `hidup`
--

INSERT INTO `hidup` (`Hidup`, `Nama`, `NA`) VALUES
('1', 'Masih Hidup', 'N'),
('2', 'Sudah Meninggal', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `identitas`
--

CREATE TABLE IF NOT EXISTS `identitas` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` int(5) NOT NULL,
  `KodeHukum` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Nama_Identitas` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `TglMulai` date NOT NULL DEFAULT '0000-00-00',
  `Alamat1` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePos` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Fax` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Website` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NoAkta` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TglAkta` date DEFAULT NULL,
  `NoSah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSah` date DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `Identitas_ID` (`Identitas_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=26 ;

--
-- Dumping data untuk tabel `identitas`
--

INSERT INTO `identitas` (`ID`, `Identitas_ID`, `KodeHukum`, `Nama_Identitas`, `TglMulai`, `Alamat1`, `Kota`, `KodePos`, `Telepon`, `Fax`, `Email`, `Website`, `NoAkta`, `TglAkta`, `NoSah`, `TglSah`, `Aktif`) VALUES
(25, 100, '-', 'Sekolah Tinggi Manajemen Informatika Prabumulih', '0000-00-00', 'Jalan Patra Prabumulih Selatan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE IF NOT EXISTS `jabatan` (
  `Jabatan_ID` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`Jabatan_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`Jabatan_ID`, `Nama`, `Def`, `NA`) VALUES
('A', 'Tenaga Pengajar', 'N', 'N'),
('B', 'Asisten Ahli', 'N', 'N'),
('C', 'Lektor', 'N', 'N'),
('D', 'Lektor Kepala', 'N', 'N'),
('E', 'Guru Besar', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatandikti`
--

CREATE TABLE IF NOT EXISTS `jabatandikti` (
  `JabatanDikti_ID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`JabatanDikti_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jabatandikti`
--

INSERT INTO `jabatandikti` (`JabatanDikti_ID`, `Nama`, `Def`, `NA`) VALUES
('01', 'AAM', 'N', 'N'),
('02', 'AA', 'N', 'N'),
('03', 'LMu', 'N', 'N'),
('04', 'LMa', 'N', 'N'),
('05', 'L', 'N', 'N'),
('06', 'LKM', 'N', 'N'),
('07', 'LK', 'N', 'N'),
('08', 'GBM', 'N', 'N'),
('09', 'GB', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `Jadwal_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tahun_ID` int(5) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Program_ID` int(5) NOT NULL,
  `Kode_Mtk` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `Ruang_ID` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Kelas` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Dosen_ID` int(11) NOT NULL,
  `Hari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Jam_Mulai` time NOT NULL DEFAULT '00:00:00',
  `Jam_Selesai` time NOT NULL DEFAULT '00:00:00',
  `UTSTgl` date NOT NULL,
  `UTSHari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `UTSMulai` time NOT NULL,
  `UTSSelesai` time NOT NULL,
  `UTSRuang` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `UASTgl` date NOT NULL,
  `UASHari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `UASMulai` time NOT NULL,
  `UASSelesai` time NOT NULL,
  `UASRuang` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `JumlahMhsw` int(11) NOT NULL,
  `Kapasitas` int(11) NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`Jadwal_ID`),
  KEY `Tahun_ID` (`Tahun_ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Program_ID` (`Program_ID`),
  KEY `Kode_Mtk` (`Kode_Mtk`),
  KEY `Kode_Jurusan` (`Jurusan_ID`),
  KEY `Ruang_ID` (`Ruang_ID`),
  KEY `Dosen_ID` (`Dosen_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=65 ;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`Jadwal_ID`, `Tahun_ID`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Kode_Mtk`, `Ruang_ID`, `Kelas`, `Dosen_ID`, `Hari`, `Jam_Mulai`, `Jam_Selesai`, `UTSTgl`, `UTSHari`, `UTSMulai`, `UTSSelesai`, `UTSRuang`, `UASTgl`, `UASHari`, `UASMulai`, `UASSelesai`, `UASRuang`, `JumlahMhsw`, `Kapasitas`, `Aktif`) VALUES
(4, 20151, 213131, 86208, 3, 'IA123', '4', '', 5, 'Senin', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(3, 20151, 213131, 86208, 3, 'IA134', '4', '', 7, 'Selasa', '15:30:00', '18:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(6, 20151, 213131, 86208, 3, 'IB125', '4', '', 13, 'Senin', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(7, 20151, 213131, 86208, 3, 'IA125', '4', '', 11, 'Selasa', '12:30:00', '15:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(8, 20152, 213131, 86208, 3, 'IA225', '4', 'P', 11, 'Kamis', '13:50:00', '16:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(9, 20152, 213131, 86208, 3, 'IC221', '4', 'P', 6, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(10, 20151, 213131, 86208, 3, 'IA122', '4', '', 24, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(11, 20151, 213131, 86208, 3, 'IB124', '4', '', 23, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(12, 20151, 213131, 86208, 3, 'IA121', '4', '', 9, 'Rabu', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(13, 20151, 213131, 86208, 3, 'IE104', '4', '', 19, 'Senin', '10:00:00', '11:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(14, 20151, 213131, 86208, 3, 'IB121', '4', '', 4, 'Kamis', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(15, 20151, 213131, 86208, 3, 'IB123', '4', '', 21, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(16, 20151, 213131, 86208, 3, 'IB3212', '14', '', 22, 'Senin', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(17, 20151, 213131, 86208, 3, 'IB3210', '14', '', 12, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(18, 20151, 213131, 86208, 3, 'IA325', '14', '', 7, 'Senin', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(19, 20151, 213131, 86208, 3, 'IA324', '14', '', 18, 'Selasa', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(20, 20151, 213131, 86208, 3, 'ID321', '14', '', 10, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(21, 20151, 213131, 86208, 3, 'IC321', '14', '', 6, 'Selasa', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(22, 20151, 213131, 86208, 3, 'IC324', '14', '', 27, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(23, 20151, 213131, 86208, 3, 'IC322', '14', '', 15, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(27, 20151, 213131, 86208, 3, 'IB122', '4', '', 14, 'Kamis', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(26, 20151, 213131, 86208, 3, 'IB126', '4', '', 2, 'Kamis', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(29, 20151, 213131, 86208, 3, 'IB329', '14', '', 14, 'Rabu', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(30, 20151, 213131, 86208, 3, 'IC333', '14', '', 8, 'Kamis', '13:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(31, 20151, 213131, 86208, 3, 'IB328', '14', '', 26, 'Kamis', '16:00:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(32, 20152, 213131, 86208, 3, 'IA226', '4', 'P', 24, 'Senin', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(33, 20152, 213131, 86208, 3, 'IA224', '4', 'P', 7, 'Selasa', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(34, 20152, 213131, 86208, 3, 'IB2210', '4', 'P', 26, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(35, 20152, 213131, 86208, 3, 'IB228', '4', 'P', 4, 'Selasa', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(36, 20152, 213131, 86208, 3, 'IB227', '4', 'P', 2, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(37, 20152, 213131, 86208, 3, 'IC222', '4', 'P', 15, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(38, 20152, 213131, 86208, 3, 'IB22.9', '4', 'P', 14, 'Rabu', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(39, 20152, 213131, 86208, 3, 'IB22.11', '4', 'P', 23, 'Kamis', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(40, 20152, 213131, 86208, 3, 'IB2211', '4', 'P', 23, 'Kamis', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(41, 20152, 213131, 86208, 3, 'IE421', '4', '', 1, 'Senin', '09:00:00', '11:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(42, 20152, 213131, 86208, 3, 'IC436', '15', 'P', 5, 'Senin', '11:00:00', '13:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(43, 20152, 213131, 86208, 3, 'IE105', '15', 'P', 21, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(44, 20152, 213131, 86208, 3, 'IA424', '15', 'P', 18, 'Senin', '15:30:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(45, 20152, 213131, 86208, 3, 'IC435', '15', 'P', 44, 'Selasa', '11:00:00', '13:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(46, 20152, 213131, 86208, 3, 'IB4210', '15', 'P', 17, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(47, 20152, 213131, 86208, 3, 'IE422', '15', 'P', 20, 'Kamis', '16:30:00', '18:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(48, 20152, 213131, 86208, 3, 'IB4213', '15', 'P', 19, 'Rabu', '13:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(49, 20152, 213131, 86208, 3, 'IB4314', '15', 'P', 16, 'Rabu', '15:40:00', '18:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(50, 20152, 213131, 86208, 3, 'IB428', '15', 'P', 26, 'Selasa', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(51, 20152, 213131, 86208, 3, 'IB429', '15', 'P', 12, 'Kamis', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(52, 20152, 213131, 86208, 3, 'IA425', '15', 'P', 7, 'Kamis', '14:40:00', '16:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(53, 20152, 213131, 86208, 3, 'IC6313', '17', 'P', 22, 'Senin', '12:10:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(54, 20152, 213131, 86208, 3, 'IC6311', '17', 'P', 10, 'Senin', '15:50:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(55, 20152, 213131, 86208, 3, 'IB6319', '17', 'P', 27, 'Selasa', '11:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(56, 20152, 213131, 86208, 3, 'IC6215', '17', 'P', 6, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(57, 20152, 213131, 86208, 3, 'IC6214', '17', '', 28, 'Selasa', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(58, 20152, 213131, 86208, 3, 'IC6312', '17', 'P', 8, 'Rabu', '13:00:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(59, 20152, 213131, 86208, 3, 'IB6321', '17', 'P', 24, 'Rabu', '14:40:00', '16:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(60, 20152, 213131, 86208, 3, 'IB6220', '17', 'P', 3, 'Kamis', '13:00:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(61, 20152, 213131, 86208, 3, 'IE623', '17', 'P', 25, 'Kamis', '14:40:00', '16:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(62, 2018, 100, 461, 3, '0', '15', '', 32, 'Senin', '00:00:00', '00:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(63, 2018, 100, 461, 3, 'WJ1', '4', 'kelas a', 32, 'Senin', '07:30:00', '09:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(64, 2018, 100, 461, 3, 'k1', '16', 'kelas B', 27, 'Senin', '00:00:00', '01:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jeniskurikulum`
--

CREATE TABLE IF NOT EXISTS `jeniskurikulum` (
  `JenisKurikulum_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Kode` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Singkatan` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Jurusan_ID` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`JenisKurikulum_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`),
  KEY `Identitas_ID` (`Kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `jeniskurikulum`
--

INSERT INTO `jeniskurikulum` (`JenisKurikulum_ID`, `Kode`, `Singkatan`, `Nama`, `Jurusan_ID`, `Aktif`) VALUES
(1, 'A', NULL, 'Inti', '', 'N'),
(2, 'B', NULL, 'Institusi', '', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenismk`
--

CREATE TABLE IF NOT EXISTS `jenismk` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `JenisMTK_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `JenisMK_ID` (`JenisMTK_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `jenismk`
--

INSERT INTO `jenismk` (`ID`, `JenisMTK_ID`, `Nama`, `Aktif`) VALUES
(1, 'A', 'WAJIB', 'Y'),
(2, 'B', 'PILIHAN', 'Y'),
(3, 'C', 'WAJIB PERMINTAAN', 'Y'),
(4, 'D', 'PILIHAN PERMINTAAN', 'Y'),
(5, 'S', 'TA/SKRIPSI/THESIS/DISERTASI', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenissekolah`
--

CREATE TABLE IF NOT EXISTS `jenissekolah` (
  `JenisSekolah_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`JenisSekolah_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `jenissekolah`
--

INSERT INTO `jenissekolah` (`JenisSekolah_ID`, `Nama`) VALUES
(4, 'Yayasan Penabur'),
(5, 'Kristen/Katolik Non Penabur'),
(3, 'Umum'),
(2, 'Negeri'),
(6, 'Luar Negeri'),
(1, 'Madrasah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_ujian`
--

CREATE TABLE IF NOT EXISTS `jenis_ujian` (
  `ID` int(1) NOT NULL AUTO_INCREMENT,
  `jenisjadwal` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `jenisjadwal` (`jenisjadwal`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `jenis_ujian`
--

INSERT INTO `jenis_ujian` (`ID`, `jenisjadwal`, `nama`) VALUES
(1, 'UTS', 'Ujian Tengah Semester'),
(2, 'UAS', 'Ujian Akhir Semester');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenjang`
--

CREATE TABLE IF NOT EXISTS `jenjang` (
  `Jenjang_ID` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Keterangan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`Jenjang_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jenjang`
--

INSERT INTO `jenjang` (`Jenjang_ID`, `Nama`, `Keterangan`, `Def`, `NA`) VALUES
('A', 'S3', 'Strata Tiga', 'N', 'N'),
('B', 'S2', 'Strata Dua', 'N', 'N'),
('C', 'S1', 'Strata Satu', 'N', 'N'),
('D', 'D4', 'Diploma 4', 'N', 'N'),
('E', 'D3', 'Diploma 3', 'N', 'N'),
('F', 'D2', 'Diploma 2', 'N', 'N'),
('G', 'D1', 'Diploma 1', 'N', 'N'),
('H', 'SP-1', 'Spesialis Satu', 'N', 'N'),
('I', 'SP-2', 'Spesialis Dua', 'N', 'N'),
('J', 'Profesi', 'Profesi', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `nama_jurusan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `jenjang` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `Akreditasi` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaKetua` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `NoSKDikti` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSKDikti` date DEFAULT NULL,
  `NoSKBAN` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSKBAN` date DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`ID`, `Identitas_ID`, `Jurusan_ID`, `nama_jurusan`, `jenjang`, `Akreditasi`, `NamaKetua`, `NoSKDikti`, `TglSKDikti`, `NoSKBAN`, `TglSKBAN`, `Aktif`) VALUES
(3, 100, 461, 'Sistem Informatika', 'S1', 'B', 'H. Agus Hermawan, M.Ag', '', '0000-00-00', '', '0000-00-00', 'Y'),
(4, 100, 460, 'Komputerisasi Akuntansi', 'D3', 'B', 'Drs. Lili Sadeli, M.Pd.I', '', '0000-00-00', '', '0000-00-00', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusansekolah`
--

CREATE TABLE IF NOT EXISTS `jurusansekolah` (
  `JurusanSekolah_ID` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaJurusan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N',
  PRIMARY KEY (`JurusanSekolah_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jurusansekolah`
--

INSERT INTO `jurusansekolah` (`JurusanSekolah_ID`, `Nama`, `NamaJurusan`, `NA`) VALUES
('011', 'SMU', 'IPA', 'N'),
('012', 'SMU', 'IPS', 'N'),
('013', 'SMU', 'A4/BAHASA', 'N'),
('021', 'STM PEMBANGUNAN', 'BANGUNAN GEDUNG', 'N'),
('022', 'STM PEMBANGUNAN', 'BANGUNAN AIR', 'N'),
('023', 'STM PEMBANGUNAN', 'MESIN PRODUKSI', 'N'),
('025', 'STM PEMBANGUNAN', 'LISTRIK INDUSTRI', 'N'),
('024', 'STM PEMBANGUNAN', 'OTOMOTIF', 'N'),
('027', 'STM PEMBANGUNAN', 'ELEKTRO KOMUNIKASI', 'N'),
('031', 'SMEA', 'TATA BUKU', 'N'),
('032', 'SMEA', 'TATA NIAGA', 'N'),
('033', 'SMEA', 'TATA USAHA', 'N'),
('101', 'STM', 'ELEKTRONIKA', 'N'),
('102', 'STM', 'LISTRIK', 'N'),
('103', 'STM', 'MESIN PRODUKSI', 'N'),
('104', 'STM', 'BANGUNAN', 'N'),
('105', 'STM', 'OTOMOTIF', 'N'),
('121', 'SMTP', 'BANGUNAN KAPAL', 'N'),
('122', 'SMTP', 'MESIN KAPAL', 'N'),
('131', 'SMTP', 'AVIONIKA', 'N'),
('132', 'SMTP', 'LISTRIK & INSTRUMEN', 'N'),
('133', 'SMTP', 'MOTOR & RANGKA', 'N'),
('350', 'SMEA PEMBANGUNAN', 'EKONOMI', 'N'),
('014', 'SMU', 'A1', 'N'),
('015', 'SMU', 'A2', 'N'),
('016', 'SMU', 'A3', 'N'),
('161', 'SPG', 'SD', 'N'),
('162', 'SPG', 'TK', 'N'),
('999', 'SMA LUAR NEGERI', '', 'N'),
('041', 'SMF', 'FARMASI', 'N'),
('042', 'SA KES', 'ANALISI KESEHATAN', 'N'),
('034', 'SMEA', 'SEKRETARIS', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kampus`
--

CREATE TABLE IF NOT EXISTS `kampus` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `Kampus_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Fax` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Kampus_ID` (`Kampus_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `kampus`
--

INSERT INTO `kampus` (`ID`, `Identitas_ID`, `Kampus_ID`, `Nama`, `Alamat`, `Kota`, `Telepon`, `Fax`, `Aktif`) VALUES
(1, '213131', 'K1', 'KAMPUS 1', '', '', '', '', 'Y'),
(4, '213131', 'K2', 'KAMPUS 2', '', NULL, NULL, NULL, 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelompokmtk`
--

CREATE TABLE IF NOT EXISTS `kelompokmtk` (
  `ID` int(1) NOT NULL AUTO_INCREMENT,
  `KelompokMtk_ID` varchar(4) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `KelompokMtk_ID` (`KelompokMtk_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `kelompokmtk`
--

INSERT INTO `kelompokmtk` (`ID`, `KelompokMtk_ID`, `Nama`, `Aktif`) VALUES
(1, 'A', 'MPK-Pengembangan Kepribadian', 'Y'),
(2, 'B', 'MKK-KEILMUAN DAN KETERAMPILAN', 'Y'),
(3, 'C', 'MKB-KEAHLIAN BERKARYA', 'Y'),
(4, 'D', 'MPB-PERILAKU BERKARYA', 'Y'),
(5, 'E', 'MBB-BERKEHIDUPAN BERMASYARAKAT', 'Y'),
(6, 'F', 'MKU/MKDU', 'Y'),
(7, 'G', 'MKDK', 'Y'),
(8, 'H', 'MKK', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `krs`
--

CREATE TABLE IF NOT EXISTS `krs` (
  `KRS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `NIM` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Tahun_ID` int(5) NOT NULL,
  `Jadwal_ID` bigint(20) NOT NULL DEFAULT '0',
  `Kode_mtk` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `SKS` int(1) NOT NULL DEFAULT '0',
  `Tugas1` int(11) NOT NULL DEFAULT '0',
  `Tugas2` int(11) NOT NULL DEFAULT '0',
  `Presensi` int(11) NOT NULL DEFAULT '0',
  `UTS` int(11) NOT NULL DEFAULT '0',
  `UAS` int(11) NOT NULL DEFAULT '0',
  `GradeNilai` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '-',
  `BobotNilai` decimal(4,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`KRS_ID`),
  KEY `NIM` (`NIM`),
  KEY `Tahun_ID` (`Tahun_ID`),
  KEY `Jadwal_ID` (`Jadwal_ID`),
  KEY `Kode_mtk` (`Kode_mtk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `krs`
--

INSERT INTO `krs` (`KRS_ID`, `NIM`, `Tahun_ID`, `Jadwal_ID`, `Kode_mtk`, `SKS`, `Tugas1`, `Tugas2`, `Presensi`, `UTS`, `UAS`, `GradeNilai`, `BobotNilai`) VALUES
(1, '2018210001', 2018, 63, 'WJ1', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2, '2018210010', 2018, 63, 'WJ1', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(3, '2018210010', 2018, 64, 'k1', 2, 0, 0, 0, 0, 0, '0', '0.00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kurikulum`
--

CREATE TABLE IF NOT EXISTS `kurikulum` (
  `Kurikulum_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Kode` varchar(8) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Sesi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JmlSesi` int(11) NOT NULL DEFAULT '2',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`Kurikulum_ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=40 ;

--
-- Dumping data untuk tabel `kurikulum`
--

INSERT INTO `kurikulum` (`Kurikulum_ID`, `Identitas_ID`, `Jurusan_ID`, `Kode`, `Nama`, `Sesi`, `JmlSesi`, `Aktif`) VALUES
(33, 213131, 86208, '20151', 'Kurikulum 20151 Gasal', NULL, 2, 'Y'),
(34, 213131, 86208, '20152', 'kurikulum 20152 Genap', NULL, 2, 'Y'),
(35, 213131, 86208, '20152', 'kurikulum semester 8', NULL, 2, 'Y'),
(36, 213131, 60202, '20151', 'Kurikulum 20151 E gasal', NULL, 2, 'Y'),
(37, 213131, 60202, '20152', 'Kurikulum 20152 E genap', NULL, 2, 'Y'),
(38, 100, 461, 'SI2018', 'SISTEM INFORMASI 2018', NULL, 2, 'Y'),
(39, 100, 460, 'KA2018', 'KOMPUTER AKUNTANSI 2018', NULL, 2, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `id_level` int(10) NOT NULL,
  `level` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `level`
--

INSERT INTO `level` (`id_level`, `level`) VALUES
(1, 'Administrator'),
(2, 'Dosen'),
(3, 'Akademik'),
(4, 'Mahasiswa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `NIM` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_level` int(1) NOT NULL DEFAULT '4',
  `Identitas_ID` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Program_ID` int(1) DEFAULT NULL,
  `Nama` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `username` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Angkatan` varchar(8) COLLATE latin1_general_ci DEFAULT NULL,
  `Tahun_ID` int(5) NOT NULL,
  `TglSKMasuk` date NOT NULL,
  `Kurikulum_ID` int(11) NOT NULL,
  `foto` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_foto.jpg',
  `StatusAwal_ID` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusMhsw_ID` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `PenasehatAkademik` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Kelamin` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `WargaNegara` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `Kebangsaan` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TempatLahir` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `Agama` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusSipil` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RT` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RW` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePos` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Propinsi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Negara` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Handphone` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatAsal` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RTAsal` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RWAsal` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePosAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PropinsiAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NegaraAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AgamaAyah` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PekerjaanAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HidupAyah` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AgamaIbu` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PekerjaanIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HidupIbu` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatOrtu` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePosOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PropinsiOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NegaraOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TeleponOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HandphoneOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `EmailOrtu` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `AsalSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AsalSekolah1` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JenisSekolah` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JurusanSekolah_ID` varchar(3) COLLATE latin1_general_ci DEFAULT NULL,
  `NilaiSekolah` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `TahunLulus` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N',
  `LulusUjian` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NilaiUjian` float unsigned NOT NULL DEFAULT '0',
  `GradeNilai` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLulus` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Lulus dari perguruan tinggi',
  `IPK` decimal(4,2) NOT NULL DEFAULT '0.00',
  `TotalSKS` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `NIM` (`NIM`),
  KEY `username` (`username`),
  KEY `Angkatan` (`Angkatan`),
  KEY `identitas_ID` (`Identitas_ID`),
  KEY `Kurikulum_ID` (`Kurikulum_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`),
  KEY `Program_ID` (`Program_ID`),
  KEY `Tahun_ID` (`Tahun_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=194 ;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`ID`, `NIM`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `username`, `password`, `Angkatan`, `Tahun_ID`, `TglSKMasuk`, `Kurikulum_ID`, `foto`, `StatusAwal_ID`, `StatusMhsw_ID`, `PenasehatAkademik`, `Kelamin`, `WargaNegara`, `Kebangsaan`, `TempatLahir`, `TanggalLahir`, `Agama`, `StatusSipil`, `Alamat`, `Kota`, `RT`, `RW`, `KodePos`, `Propinsi`, `Negara`, `Telepon`, `Handphone`, `Email`, `AlamatAsal`, `KotaAsal`, `RTAsal`, `RWAsal`, `KodePosAsal`, `PropinsiAsal`, `NegaraAsal`, `NamaAyah`, `AgamaAyah`, `PendidikanAyah`, `PekerjaanAyah`, `HidupAyah`, `NamaIbu`, `AgamaIbu`, `PendidikanIbu`, `PekerjaanIbu`, `HidupIbu`, `AlamatOrtu`, `KotaOrtu`, `KodePosOrtu`, `PropinsiOrtu`, `NegaraOrtu`, `TeleponOrtu`, `HandphoneOrtu`, `EmailOrtu`, `AsalSekolah`, `AsalSekolah1`, `JenisSekolah`, `KotaSekolah`, `JurusanSekolah_ID`, `NilaiSekolah`, `TahunLulus`, `aktif`, `LulusUjian`, `NilaiUjian`, `GradeNilai`, `TanggalLulus`, `IPK`, `TotalSKS`) VALUES
(97, '2018220021', 4, '100', 460, 3, 'AYU LESTARI', '2018220021', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(96, '2018220020', 4, '100', 460, 3, 'HARTATI', '2018220020', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(95, '2018220019', 4, '100', 460, 3, 'M. RAFLI PRASETYA', '2018220019', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(94, '2018220018', 4, '100', 460, 3, 'M. ALFARISI LUIS', '2018220018', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(93, '2018220017', 4, '100', 460, 3, 'AYU PRATIWI', '2018220017', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(92, '2018220016', 4, '100', 460, 3, 'SUCI SILVERA', '2018220016', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(91, '2018220015', 4, '100', 460, 3, 'RISKA APRIDILA S', '2018220015', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(90, '201822014P', 4, '100', 460, 3, 'VIRDAN GHIFARI', '201822014P', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(89, '2018220013', 4, '100', 460, 3, 'ELVIN CERIS MAYANA', '2018220013', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(88, '2018220012', 4, '100', 460, 3, 'PUTRI MARLINA', '2018220012', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(87, '2018220011', 4, '100', 460, 3, 'AFREZA PUJI LESTARI', '2018220011', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(86, '2018220010', 4, '100', 460, 3, 'FITRIANI WULANDARI', '2018220010', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(85, '2018220009', 4, '100', 460, 3, 'PUJIAN SARI', '2018220009', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(84, '2018220008', 4, '100', 460, 3, 'MOSEP ILJAYA', '2018220008', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(83, '2018220007', 4, '100', 460, 3, 'RESNA AGUSTIN', '2018220007', '22cc04362b615eeb3a074da0112377932e63fdd3d6b54a32a06281d82b83e417319af9c18bca7ed1f4c200aa12ab0ebb81d6dd362a097f380274a8569499e55a', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '0', '0', '', 'P', '', '', '', '0000-00-00', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '0', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(82, '2018220006', 4, '100', 460, 3, 'MEYLU DIANTE', '2018220006', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(81, '2018220005', 4, '100', 460, 3, 'RINI ANTIKA', '2018220005', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(80, '2018220004', 4, '100', 460, 3, 'NOVI AFRIANTI', '2018220004', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(79, '2018220003', 4, '100', 460, 3, 'DELLA SABILLAH PUTRI', '2018220003', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(78, '2018220002', 4, '100', 460, 3, 'FEBI JUNI ASTUTI', '2018220002', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(77, '2018220001', 4, '100', 460, 3, 'IVAN HADI PUTRA', '2018220001', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 39, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(75, '2018210075', 4, '100', 461, 3, 'ANGGUN KRIS SHINDY', '2018210075', 'd289c168849630a7985dae8246e2468129a813662644a7f120cbecd6dd3add8ea6db282d6980f0a304142903e0fa830ce7f9d82f31e55c033a5cf914bc89da74', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '0', '0', '', 'P', '', '', '', '0000-00-00', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', '', '', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '0', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(76, '2018210076', 4, '100', 461, 3, 'M. FIRMANSYAH', '2018210076', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(74, '201821074P', 4, '100', 461, 3, 'DINI CINDY ADELIMA', '201821074P', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(73, '2018210073', 4, '100', 461, 3, 'REFLITHA CHESTY ARYANI', '2018210073', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(72, '2018210072', 4, '100', 461, 3, 'M. RIFQI RAMADHAN', '2018210072', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(71, '2018210071', 4, '100', 461, 3, 'YULNI FARISKA', '2018210071', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(70, '2018210070', 4, '100', 461, 3, 'MUHAMMAD AYUB', '2018210070', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(69, '2018210069', 4, '100', 461, 3, 'DASRI KARNIA', '2018210069', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(68, '2018210068', 4, '100', 461, 3, 'PEBRIANI AJI PUTRI.P', '2018210068', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(67, '2018210067', 4, '100', 461, 3, 'DINI OCTARIANI', '2018210067', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(66, '2018210066', 4, '100', 461, 3, 'IKE TRISIA NOPIANI', '2018210066', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(65, '2018210065', 4, '100', 461, 3, 'RIMA RENATA LIA KINKI', '2018210065', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(64, '2018210064', 4, '100', 461, 3, 'PRAMUDYA SATRIA ABIMAYU', '2018210064', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(63, '2018210063', 4, '100', 461, 3, 'ALPINA DAMAYANTI', '2018210063', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(62, '2018210062', 4, '100', 461, 3, 'HEVI AGUSTINA', '2018210062', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(61, '2018210061', 4, '100', 461, 3, 'RAMAH DONI', '2018210061', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(60, '2018210060', 4, '100', 461, 3, 'JUNIS HADI SAPUTRA', '2018210060', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(59, '2018210059', 4, '100', 461, 3, 'WULAN KARNITA SEPTRI', '2018210059', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(58, '2018210058', 4, '100', 461, 3, 'REGITA KINANTI', '2018210058', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(57, '2018210057', 4, '100', 461, 3, 'FERJIELIA DWI YOSHA', '2018210057', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(56, '2018210056', 4, '100', 461, 3, 'ANNISA SAFITRI', '2018210056', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(55, '2018210055', 4, '100', 461, 3, 'AKIPSYA', '2018210055', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(54, '201821054P', 4, '100', 461, 3, 'MIRANTI', '201821054P', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(53, '2018210053', 4, '100', 461, 3, 'HAMAT HARUN', '2018210053', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(52, '2018210052', 4, '100', 461, 3, 'TRI ULFA APRIANI', '2018210052', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(51, '2018210051', 4, '100', 461, 3, 'REYBALDO DWI RAMADHAN', '2018210051', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(50, '2018210050', 4, '100', 461, 3, 'REDHO SEPTRA NOVRI', '2018210050', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(49, '2018210049', 4, '100', 461, 3, 'DESTIN SELVARIA', '2018210049', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(48, '2018210048', 4, '100', 461, 3, 'PESONA LIDIYA', '2018210048', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(47, '2018210047', 4, '100', 461, 3, 'INDAH SURYANI PUSPITA. S', '2018210047', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(46, '2018210046', 4, '100', 461, 3, 'AMRI GUMAWAN MALIK', '2018210046', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(45, '2018210045', 4, '100', 461, 3, 'APRINO ALI', '2018210045', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(44, '2018210044', 4, '100', 461, 3, 'INES CLORENZA INDASARI', '2018210044', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(43, '2018210043', 4, '100', 461, 3, 'ERLANGGA PRATAMA SAPUTRA', '2018210043', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(42, '2018210042', 4, '100', 461, 3, 'MEYRISKA SILVIA ZULKARNAIN', '2018210042', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(41, '2018210041', 4, '100', 461, 3, 'NOVA MARLINA', '2018210041', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(40, '2018210040', 4, '100', 461, 3, 'IRBAH FARIHAH', '2018210040', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(39, '2018210039', 4, '100', 461, 3, 'AHMAD DZAKIR HABIBI', '2018210039', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(38, '2018210038', 4, '100', 461, 3, 'RISKI PUTRA', '2018210038', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(37, '2018210037', 4, '100', 461, 3, 'YOGA DIAN PRATAMA', '2018210037', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(36, '2018210036', 4, '100', 461, 3, 'JULISA ADITYA', '2018210036', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(35, '2018210035', 4, '100', 461, 3, 'OKTRIANTI WULANDARI', '2018210035', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(34, '2018210034', 4, '100', 461, 3, 'MAWARNI', '2018210034', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(33, '2018210033', 4, '100', 461, 3, 'ARANDA HANSEN ARISKA PUTRA', '2018210033', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(32, '2018210032', 4, '100', 461, 3, 'SILVA VERONICA', '2018210032', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(31, '2018210031', 4, '100', 461, 3, 'YULIANI', '2018210031', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(30, '2018210030', 4, '100', 461, 3, 'YURIZKI IMANI TIRTASARI', '2018210030', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(28, '2018210028', 4, '100', 461, 3, 'ZAMLAWI', '2018210028', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(29, '2018210029', 4, '100', 461, 3, 'RETNO WATI', '2018210029', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(27, '2018210027', 4, '100', 461, 3, 'FENUS FERNANDO', '2018210027', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(26, '2018210026', 4, '100', 461, 3, 'MITA PRATIWI', '2018210026', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(25, '2018210025', 4, '100', 461, 3, 'RIZKY RIAS POLITIKA', '2018210025', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(24, '2018210024', 4, '100', 461, 3, 'ANGGIE SRI WAHYUNI', '2018210024', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(23, '201821023P', 4, '100', 461, 3, 'ILHAM PRAJA KUSUMA', '201821023P', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(22, '2018210022', 4, '100', 461, 3, 'REZA HIKMAH TULLAH', '2018210022', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(21, '2018210021', 4, '100', 461, 3, 'M. PREDY', '2018210021', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(20, '2018210020', 4, '100', 461, 3, 'ARDELIYA', '2018210020', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(19, '2018210019', 4, '100', 461, 3, 'RIFTA AL MUNAWAROH', '2018210019', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(18, '2018210018', 4, '100', 461, 3, 'NADILA MAHARANI', '2018210018', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(17, '2018210017', 4, '100', 461, 3, 'NADIAH', '2018210017', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(16, '2018210016', 4, '100', 461, 3, 'AYU UMITA SARI INDRIANI', '2018210016', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(15, '2018210015', 4, '100', 461, 3, 'ERLI YUNANI', '2018210015', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(14, '2018210014', 4, '100', 461, 3, 'DESTINA ULFA SARI', '2018210014', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(13, '2018210013', 4, '100', 461, 3, 'ERLIN SURNA NINGSIH', '2018210013', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(12, '2018210012', 4, '100', 461, 3, 'MEISAKDAK PERMATA SARI', '2018210012', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(11, '2018210011', 4, '100', 461, 3, 'SELVY OKTARINA', '2018210011', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(10, '2018210010', 4, '100', 461, 3, 'EMELDA', '2018210010', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(9, '2018210009', 4, '100', 461, 3, 'DWINES CINTHIA', '2018210009', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(8, '2018210008', 4, '100', 461, 3, 'NIKE YAYU LESTARI', '2018210008', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(7, '2018210007', 4, '100', 461, 3, 'SALSABILA ERLIA PUTRI', '2018210007', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(6, '2018210006', 4, '100', 461, 3, 'THABITA LEONI POLNAYA', '2018210006', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(5, '2018210005', 4, '100', 461, 3, 'OFIK WAHYU BETA AGUNG', '2018210005', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(4, '2018210004', 4, '100', 461, 3, 'TUTI LASTARI', '2018210004', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(3, '2018210003', 4, '100', 461, 3, 'RIZKI AGUSTIAN', '2018210003', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(1, '2018210001', 4, '100', 461, 3, 'KARINDA BELLA BR PASARIBU', '2018210001', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0),
(2, '2018210002', 4, '100', 461, 3, 'RIA ARISKA', '2018210002', '8ddd2bf1df067897bbc7a4217d80224d233aa0d71aa94dfc6e8fc4499a16a124ef15e7428530ddf77f2294b95f424b5059f265fce0b4736826ba6accbac0fe9b', '2018', 0, '0000-00-00', 38, 'no_foto.jpg', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '0000-00-00', '0.00', 0);
INSERT INTO `mahasiswa` (`ID`, `NIM`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `username`, `password`, `Angkatan`, `Tahun_ID`, `TglSKMasuk`, `Kurikulum_ID`, `foto`, `StatusAwal_ID`, `StatusMhsw_ID`, `PenasehatAkademik`, `Kelamin`, `WargaNegara`, `Kebangsaan`, `TempatLahir`, `TanggalLahir`, `Agama`, `StatusSipil`, `Alamat`, `Kota`, `RT`, `RW`, `KodePos`, `Propinsi`, `Negara`, `Telepon`, `Handphone`, `Email`, `AlamatAsal`, `KotaAsal`, `RTAsal`, `RWAsal`, `KodePosAsal`, `PropinsiAsal`, `NegaraAsal`, `NamaAyah`, `AgamaAyah`, `PendidikanAyah`, `PekerjaanAyah`, `HidupAyah`, `NamaIbu`, `AgamaIbu`, `PendidikanIbu`, `PekerjaanIbu`, `HidupIbu`, `AlamatOrtu`, `KotaOrtu`, `KodePosOrtu`, `PropinsiOrtu`, `NegaraOrtu`, `TeleponOrtu`, `HandphoneOrtu`, `EmailOrtu`, `AsalSekolah`, `AsalSekolah1`, `JenisSekolah`, `KotaSekolah`, `JurusanSekolah_ID`, `NilaiSekolah`, `TahunLulus`, `aktif`, `LulusUjian`, `NilaiUjian`, `GradeNilai`, `TanggalLulus`, `IPK`, `TotalSKS`) VALUES
(193, 'NIM', 0, 'Identitas_', 0, 0, 'Nama', 'username', 'password', 'Angkatan', 0, '0000-00-00', 0, 'foto', 'Statu', 'Statu', 'PenasehatAkademik', 'Kel', 'War', 'Kebangsaan', 'TempatLahir', '0000-00-00', 'Agama', 'StatusSipil', 'Alamat', 'Kota', 'RT', 'RW', 'KodePos', 'Propinsi', 'Negara', 'Telepon', 'Handphone', 'Email', 'AlamatAsal', 'KotaAsal', 'RTAsal', 'RWAsal', 'KodePosAsal', 'PropinsiAsal', 'NegaraAsal', 'NamaAyah', 'AgamaAyah', 'PendidikanAyah', 'PekerjaanAyah', 'Hidup', 'NamaIbu', 'AgamaIbu', 'PendidikanIbu', 'PekerjaanIbu', 'Hidup', 'AlamatOrtu', 'KotaOrtu', 'KodePosOrtu', 'PropinsiOrtu', 'NegaraOrtu', 'TeleponOrtu', 'HandphoneOrtu', 'EmailOrtu', 'AsalSekolah', 'AsalSekolah1', 'JenisSekolah', 'KotaSekolah', 'Jur', 'NilaiSekol', 'TahunLulus', '', '', 0, 'Grade', '0000-00-00', '0.00', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `master_nilai`
--

CREATE TABLE IF NOT EXISTS `master_nilai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipmin` decimal(5,2) NOT NULL,
  `ipmax` decimal(5,2) NOT NULL,
  `MaxSKS` int(3) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `master_nilai`
--

INSERT INTO `master_nilai` (`id`, `ipmin`, `ipmax`, `MaxSKS`, `Identitas_ID`, `Jurusan_ID`) VALUES
(1, '1.20', '1.69', 12, 14032012, 261),
(2, '1.70', '2.19', 16, 14032012, 261),
(3, '2.20', '2.69', 19, 14032012, 261),
(4, '2.70', '2.99', 21, 14032012, 261),
(5, '3.00', '4.00', 24, 14032012, 261),
(6, '0.00', '1.19', 9, 14032012, 261);

-- --------------------------------------------------------

--
-- Struktur dari tabel `matakuliah`
--

CREATE TABLE IF NOT EXISTS `matakuliah` (
  `Matakuliah_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Kurikulum_ID` int(11) NOT NULL,
  `Kode_mtk` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `Nama_matakuliah` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Nama_english` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Semester` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `SKS` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `KelompokMtk_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `JenisMTK_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `JenisKurikulum_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `StatusMtk_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Penanggungjawab` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Ket` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`Matakuliah_ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Kode_mtk` (`Kode_mtk`),
  KEY `Jurusan_ID` (`Jurusan_ID`),
  KEY `Kurikulum_ID` (`Kurikulum_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=193 ;

--
-- Dumping data untuk tabel `matakuliah`
--

INSERT INTO `matakuliah` (`Matakuliah_ID`, `Identitas_ID`, `Jurusan_ID`, `Kurikulum_ID`, `Kode_mtk`, `Nama_matakuliah`, `Nama_english`, `Semester`, `SKS`, `KelompokMtk_ID`, `JenisMTK_ID`, `JenisKurikulum_ID`, `StatusMtk_ID`, `Penanggungjawab`, `Ket`, `Aktif`) VALUES
(107, 213131, 86208, 34, 'IB22.9', 'Hadist 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(106, 213131, 86208, 34, 'IC222', 'Ilmu Pendidikan 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(105, 213131, 86208, 34, 'IB227', 'Sejarah Peradaban Islam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(104, 213131, 86208, 34, 'IB228', 'Fiqh 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(103, 213131, 86208, 34, 'IB2210', 'Tafsir 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(102, 213131, 86208, 34, 'IA224', 'Bahasa Inggris 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(101, 213131, 86208, 34, 'IA226', 'Filsafat Umum', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(100, 213131, 86208, 34, 'IC221', 'MKPAI 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(98, 213131, 86208, 33, 'IB7022', 'Teori/Bimbingan Skripsi', '', '7', '2', '0', 'S', '0', 'A', '', '', 'Y'),
(99, 213131, 86208, 34, 'IA225', 'Bahasa Arab 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(97, 213131, 86208, 33, 'IC333', 'Filsafat Pendidikan Islam', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(96, 213131, 86208, 33, 'IB5218', 'Qira''atul kutub', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(95, 213131, 86208, 33, 'IB5316', 'Etika dan Profesi Guru', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(94, 213131, 86208, 33, 'IB5315', 'Micro Teaching 1', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(93, 213131, 86208, 33, 'IC538', 'Psikologi Agama', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(92, 213131, 86208, 33, 'IC529', 'Peng. Sistem Evaluasi PAI', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(91, 213131, 86208, 33, 'ID532', 'Bimbingan Konseling', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(90, 213131, 86208, 33, 'IC527', 'Telaah Kurikulum PAI SLTP/SLTA', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(89, 213131, 86208, 33, 'IB5217', 'Filsafat Ilmu', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(88, 213131, 86208, 33, 'IB328', 'Fiqh 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(87, 213131, 86208, 33, 'IC333', 'Peren. Sistem Pengajaran PAI', '', '3', '3', '0', '0', '0', 'A', '', '', 'Y'),
(86, 213131, 86208, 33, 'IB329', 'Hadits 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(85, 213131, 86208, 33, 'IC322', 'Ilmu Pendidikan 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(84, 213131, 86208, 33, 'IC324', 'Psikologi Pendidikan', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(83, 213131, 86208, 33, 'IC321', 'MKPAI 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(82, 213131, 86208, 33, 'ID321', 'Komunikasi Pembelajaran', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(81, 213131, 86208, 33, 'IA324', 'Bahasa Inggris 3', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(80, 213131, 86208, 33, 'IA325', 'Bahasa Arab 3', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(79, 213131, 86208, 33, 'IB3210', 'Tafsir 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(78, 213131, 86208, 33, 'IB3212', 'Filsafat Islam', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(77, 213131, 86208, 33, 'IB122', 'Ulumul Hadist', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(76, 213131, 86208, 33, 'IB126', 'Akhlak Tasawuf', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(75, 213131, 86208, 33, 'IB121', 'Ilmu Fiqh', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(74, 213131, 86208, 33, 'IA121', 'PPkn', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(73, 213131, 86208, 33, 'IB124', 'Ilmu Kalam', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(72, 213131, 86208, 33, 'IA122', 'Ilmu Alamiah Dasar', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(71, 213131, 86208, 33, 'IA134', 'Bahasa Inggris', '', '1', '3', '0', '0', '0', 'A', '', '', 'Y'),
(70, 213131, 86208, 33, 'IA125', 'Bahasa Arab 1', '', '1', '3', '0', '0', '0', 'A', '', '', 'Y'),
(69, 213131, 86208, 33, 'IB125', 'Psikologi Umum', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(68, 213131, 86208, 33, 'IB123', 'Ulumul Qur’an', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(67, 213131, 86208, 33, 'IA123', 'Bahasa Indonesia', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(66, 213131, 86208, 33, 'IE104', 'Praktek Ibadah', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(108, 213131, 86208, 34, 'IB2211', 'Psikologi Perkembangan', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(109, 213131, 86208, 34, 'IE421', 'Komputer', '', '2', '3', '0', '0', '0', 'A', '', '', 'Y'),
(110, 213131, 86208, 34, 'IC436', 'Media dan Teknologi Pengajaran', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(111, 213131, 86208, 34, 'IE105', 'Praktek Tilawah', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(112, 213131, 86208, 34, 'IA424', 'Bahasa Inggris 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(113, 213131, 86208, 34, 'IC435', ' Statistik Pendidikan', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(114, 213131, 86208, 34, 'IB4210', 'Tafsir 3', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(115, 213131, 86208, 34, 'IE422', 'Manajemen Masjid', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(116, 213131, 86208, 34, 'IB4213', 'Ilmu pendidikan Islam', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(117, 213131, 86208, 34, 'IB4314', 'Strategi Belajar Mengajar', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(118, 213131, 86208, 34, 'IB428', 'Fiqih 3', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(119, 213131, 86208, 34, 'IA425', 'Bhasa Arab 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(120, 213131, 86208, 34, 'IB429', 'Hadits 3', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(121, 213131, 86208, 34, 'IC6313', 'Administrasi Pendidikan', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(122, 213131, 86208, 34, 'IC6311', 'Metode Penelitian', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(123, 213131, 86208, 34, 'IB6319', 'Kapita Selekta Pendidikan', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(124, 213131, 86208, 34, 'IC6215', 'Manajemen Sekolah', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(125, 213131, 86208, 34, 'IC6214', 'Micro Teaching', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(126, 213131, 86208, 34, 'IC6312', 'Pengembangan Kurikulum PAI', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(127, 213131, 86208, 34, 'IB6321', 'Metodologi Studi Islam', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(128, 213131, 86208, 34, 'IE623', 'Jasa Kewirausahaan', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(129, 213131, 86208, 34, 'IB6220', 'Masailul Fiqhiyah', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(130, 213131, 86208, 33, 'ID724', 'KKN', '', '7', '2', 'B', 'C', '0', 'A', '', '', 'Y'),
(131, 213131, 86208, 35, 'ID825', 'Komprehensip', '', '8', '2', 'H', 'A', '0', 'A', '', '', 'Y'),
(132, 213131, 86208, 35, 'ID846', 'Skripsi', '', '8', '4', 'H', 'S', '0', 'A', '', '', 'Y'),
(133, 213131, 86208, 34, 'ID723', 'PPLK', '', '7', '2', 'B', 'C', '0', 'A', '', '', 'Y'),
(134, 213131, 60202, 36, 'D104', 'Pengantar Ekonomi', '', '1', '3', '0', '0', '0', 'A', '', '', 'Y'),
(135, 213131, 60202, 36, 'A111', 'Bahasa Indonesia', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(136, 213131, 60202, 36, 'A108', 'Bahasa Arab 1', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(137, 213131, 60202, 36, 'B100', 'PKN/Pancasila', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(138, 213131, 60202, 36, 'A109', 'Kewirausahaan 1', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(139, 213131, 60202, 36, 'C113', 'Praktek Ibadah', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(140, 213131, 60202, 36, 'A105', 'Pengantar Akutansi', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(141, 213131, 60202, 36, 'A100', 'Ulumul Qur', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(142, 213131, 60202, 36, 'A104', 'Pengantar Fiqih Muamalah', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(143, 213131, 60202, 36, 'D105', 'Filsafat Umum', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(144, 213131, 60202, 36, 'A112', 'Akhlak Tasawuf', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(145, 213131, 60202, 36, 'B108', 'Ekonomi Mikro Islam', '', '3', '3', '0', '0', '0', 'A', '', '', 'Y'),
(146, 213131, 60202, 36, 'B109', 'Manajemen Koperasi', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(147, 213131, 60202, 36, 'B110', 'Bahasa Inggris', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(148, 213131, 60202, 36, 'B105', 'Sejarah Pemikiran Eksyar', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(149, 213131, 60202, 36, 'C110', 'Kaidah Fiqih Muamalah ', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(150, 213131, 60202, 36, 'D101', 'Kewirausahaan 3', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(151, 213131, 60202, 36, 'B107', 'Fiqih Muamalah 2', '', '3', '3', '0', '0', '0', 'A', '', '', 'Y'),
(152, 213131, 60202, 36, 'C100', 'Hadits Ekonomi', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(153, 213131, 60202, 36, 'B104', 'Pengantar Ilmu Hukum', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(154, 213131, 60202, 36, 'D102', 'Dasar - dasar Manajemen', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(155, 213131, 60202, 36, 'C103', 'Kewirausahan 5', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(156, 213131, 60202, 36, 'C104', 'Asuransi  Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(157, 213131, 60202, 36, 'D103', 'Keuangan Publik Islam', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(158, 213131, 60202, 36, 'D106', 'Manajemen Perbankan Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(159, 213131, 60202, 36, 'B118', 'Pasar Modal Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(160, 213131, 60202, 36, 'D110', 'Manajemen Pembiayaan', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(161, 213131, 60202, 36, 'E107', 'Kebijakan Perekonomian di Indonesia', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(162, 213131, 60202, 36, 'C105', 'Fatwa - fatwa Ekonomi Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(163, 213131, 60202, 36, 'C106', 'Manajemen Organisasi', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(164, 213131, 60202, 36, 'C107', 'Akuntansi Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(165, 213131, 60202, 36, 'C109', 'Manajemen Strategis', '', '7', '2', '0', '0', '0', 'A', '', '', 'Y'),
(166, 213131, 60202, 36, 'D111', 'Manajemen SDM/Insan Kamil', '', '7', '2', '0', '0', '0', 'A', '', '', 'Y'),
(167, 213131, 60202, 36, 'D108', 'Seminar Proposal Skripsi', '', '7', '2', '0', '0', '0', 'A', '', '', 'Y'),
(168, 213131, 60202, 36, 'C112', 'Metode Statistik', '', '7', '3', '0', '0', '0', 'A', '', '', 'Y'),
(169, 213131, 60202, 36, 'D109', 'Metodologi Penelitian Eksyar', '', '7', '3', '0', '0', '0', 'A', '', '', 'Y'),
(170, 213131, 60202, 37, 'D112', 'Skripsi', '', '8', '4', '0', 'S', '0', 'A', '', '', 'Y'),
(171, 213131, 60202, 37, 'D100', 'Pengantar Bisnis dan Manajemen', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(172, 213131, 60202, 37, 'B103', 'Bahasa Inggris', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(173, 213131, 60202, 37, 'A107', 'Ulumul Hadits', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(174, 213131, 60202, 37, 'C114', 'Komputer', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(175, 213131, 60202, 37, 'E106', 'Sejarah Peradaban Islam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(176, 213131, 60202, 37, 'A103', 'Ushul Fiqih', '', '2', '3', '0', '0', '0', 'A', '', '', 'Y'),
(177, 213131, 60202, 37, 'A110', 'Kewirausahaan 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(178, 213131, 60202, 37, 'B101', 'Bahasa Arab Ekonomi', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(179, 213131, 60202, 37, 'B102', 'Ilmu Sosial Dasar', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(180, 213131, 60202, 37, 'A102', 'Ilmu Kalam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(181, 213131, 60202, 37, 'A101', 'Fiqih Muamalah 1', '', '2', '3', '0', '0', '0', 'A', '', '', 'Y'),
(182, 213131, 60202, 37, 'C111', 'Akuntansi keuangan', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(183, 213131, 60202, 37, 'C115', 'Fiqih ZIS', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(184, 213131, 60202, 37, 'B111', 'Kewirausahaan 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(185, 213131, 60202, 37, 'B113', 'Manajemen Pemasaran', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(186, 213131, 60202, 37, 'B112', 'Lembaga Keuangan Syariah', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(187, 213131, 60202, 37, 'D113', 'Manajemen ZIS, Haji, dan Waqaf', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(188, 213131, 60202, 37, 'B106', 'Fiqih Mawarits dan Waqaf', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(189, 213131, 60202, 37, 'B115', 'Metode Statistik', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(191, 100, 461, 38, 'k1', 'k1e', '', '1', '2', 'A', 'A', '1', 'A', '', '', 'Y'),
(192, 100, 461, 38, 'WJ1', 'JARINGAN', 'NETWORK', '1', '2', 'A', 'A', '1', 'A', 'ARIANSYAH', '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
  `Nilai_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `grade` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `bobot` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `NilaiMin` decimal(10,2) NOT NULL,
  `NilaiMax` decimal(10,2) NOT NULL,
  `keterangan` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`Nilai_ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

--
-- Dumping data untuk tabel `nilai`
--

INSERT INTO `nilai` (`Nilai_ID`, `Identitas_ID`, `Jurusan_ID`, `grade`, `bobot`, `NilaiMin`, `NilaiMax`, `keterangan`, `Aktif`) VALUES
(1, 100, 461, 'E', '0', '0.00', '2.99', 'Buruk Sekali', 'Y'),
(2, 100, 461, 'D', '1', '3.00', '4.99', 'Buruk', 'Y'),
(3, 100, 461, 'C', '2', '5.00', '6.99', 'Baik', 'Y'),
(4, 100, 461, 'B', '3', '7.00', '8.99', 'Baik Sekali', 'Y'),
(5, 100, 461, 'A', '4', '9.00', '100.00', 'Istimewa', 'Y'),
(6, 100, 460, 'E', '0', '0.00', '2.99', 'Buruk Sekali', 'Y'),
(7, 100, 460, 'D', '1', '3.00', '4.99', 'Buruk', 'Y'),
(8, 100, 460, 'C', '2', '5.00', '6.99', 'Baik', 'Y'),
(9, 100, 460, 'B', '3', '7.00', '8.99', 'Baik Sekali', 'Y'),
(10, 100, 460, 'A', '4', '9.00', '100.00', 'Istimewa', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pekerjaanortu`
--

CREATE TABLE IF NOT EXISTS `pekerjaanortu` (
  `Pekerjaan` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`Pekerjaan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `pekerjaanortu`
--

INSERT INTO `pekerjaanortu` (`Pekerjaan`, `Nama`, `NA`) VALUES
('1', 'Pegawai Negeri', 'N'),
('2', 'ABRI', 'N'),
('3', 'Pegawai Swasta', 'N'),
('4', 'Usaha Sendiri', 'N'),
('5', 'Tidak Bekerja', 'N'),
('6', 'Pensiun', 'N'),
('7', 'Lain-lain', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendidikanortu`
--

CREATE TABLE IF NOT EXISTS `pendidikanortu` (
  `ID` int(1) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

--
-- Dumping data untuk tabel `pendidikanortu`
--

INSERT INTO `pendidikanortu` (`ID`, `Nama`, `NA`) VALUES
(1, 'Tidak Tamat SD', 'N'),
(2, 'Tamat SD', 'N'),
(3, 'Tamat SMP', 'N'),
(4, 'Tamat SMTA', 'N'),
(5, 'Diploma', 'N'),
(6, 'Sarjana Muda', 'N'),
(7, 'Sarjana', 'N'),
(8, 'Pasca Sarjana', 'N'),
(9, 'Doktor', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perhatian`
--

CREATE TABLE IF NOT EXISTS `perhatian` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `header` text COLLATE latin1_general_ci NOT NULL,
  `t1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t3` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t4` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t5` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t6` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `gb` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `perhatian`
--

INSERT INTO `perhatian` (`ID`, `header`, `t1`, `t2`, `t3`, `t4`, `t5`, `t6`, `gb`) VALUES
(1, '::.Warning.:: KRS YANG TELAH DI SEND/SUBMIT/KIRIM TDK BISA DIEDIT PASTIKAN SEBELUM DISEND TELITI DULU:', '1. Batas Akhir pengisian Kartu Rencana Studi (KRS) dimulai pada tanggal', '2. Perubahan Kartu Rencana Studi (KRS) tidak akan dilayani jika batas penginputan KRS telah berakhir', '', '', '', '', 'warning.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `ID` int(2) NOT NULL AUTO_INCREMENT,
  `Identitas_ID` int(5) NOT NULL,
  `Program_ID` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `nama_program` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `Program_ID` (`Program_ID`),
  KEY `Identitas_ID` (`Identitas_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `program`
--

INSERT INTO `program` (`ID`, `Identitas_ID`, `Program_ID`, `nama_program`, `aktif`) VALUES
(3, 100, 'R', 'REGULER', 'Y'),
(4, 100, 'N', 'NON REGULER', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `regmhs`
--

CREATE TABLE IF NOT EXISTS `regmhs` (
  `ID_Reg` int(11) NOT NULL AUTO_INCREMENT,
  `Tahun` int(5) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `NIM` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `tgl_reg` date NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ID_Reg`),
  KEY `Tahun` (`Tahun`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`),
  KEY `NIM` (`NIM`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=48 ;

--
-- Dumping data untuk tabel `regmhs`
--

INSERT INTO `regmhs` (`ID_Reg`, `Tahun`, `Identitas_ID`, `Jurusan_ID`, `NIM`, `tgl_reg`, `aktif`) VALUES
(1, 0, 14032012, 86208, 'B.2015.1.1.001', '2016-02-04', 'Y'),
(2, 20152, 213131, 86208, 'B.2015.1.1.001', '2016-02-04', 'Y'),
(3, 20152, 213131, 60202, 'B.2015.1.1.002', '2016-02-05', 'Y'),
(4, 20152, 213131, 60202, 'B.2015.1.1.003', '2016-02-05', 'Y'),
(5, 20152, 213131, 60202, 'B.2015.1.1.004', '2016-02-05', 'Y'),
(6, 20152, 213131, 60202, 'B.2015.1.1.005', '2016-02-05', 'Y'),
(8, 20152, 213131, 86208, 'B.2015.1.1.006', '2016-02-07', 'Y'),
(9, 20152, 213131, 86208, 'B.2015.1.1.007', '2016-02-07', 'Y'),
(10, 20152, 213131, 86208, 'B.2015.1.1.008', '2016-02-07', 'Y'),
(11, 20152, 213131, 86208, 'B.2015.1.1.009', '2016-02-07', 'Y'),
(12, 20152, 213131, 86208, 'B.2015.1.1.010', '2016-02-07', 'Y'),
(13, 20152, 213131, 86208, 'B.2015.1.1.021', '2016-02-07', 'Y'),
(14, 20152, 213131, 86208, 'B.2015.1.1.020', '2016-02-07', 'Y'),
(15, 20152, 213131, 86208, 'B.2015.1.1.019', '2016-02-07', 'Y'),
(16, 20152, 213131, 86208, 'B.2015.1.1.018', '2016-02-07', 'Y'),
(17, 20152, 213131, 86208, 'B.2015.1.1.016', '2016-02-07', 'Y'),
(18, 20152, 213131, 86208, 'B.2015.1.1.015', '2016-02-07', 'Y'),
(19, 20152, 213131, 86208, 'B.2015.1.1.014', '2016-02-07', 'Y'),
(20, 20152, 213131, 86208, 'B.2015.1.1.013', '2016-02-07', 'Y'),
(21, 20152, 213131, 86208, 'B.2015.1.1.012', '2016-02-07', 'Y'),
(22, 20152, 213131, 86208, 'B.2015.1.1.011', '2016-02-07', 'Y'),
(23, 20152, 213131, 86208, 'B.2015.1.1.022', '2016-02-07', 'Y'),
(24, 20152, 213131, 86208, 'B.2015.1.1.023', '2016-02-07', 'Y'),
(25, 20152, 213131, 86208, 'B.2015.1.1.024', '2016-02-07', 'Y'),
(26, 20152, 213131, 86208, 'B.2015.1.1.025', '2016-02-07', 'Y'),
(27, 20152, 213131, 86208, 'B.2015.1.1.026', '2016-02-07', 'Y'),
(28, 20152, 213131, 86208, 'B.2015.1.1.027', '2016-02-07', 'Y'),
(29, 20152, 213131, 86208, 'B.2015.1.1.028', '2016-02-07', 'Y'),
(30, 20152, 213131, 86208, 'B.2015.1.1.029', '2016-02-07', 'Y'),
(31, 20152, 213131, 86208, 'B.2015.1.1.030', '2016-02-07', 'Y'),
(32, 20152, 213131, 86208, 'B.2015.1.1.031', '2016-02-07', 'Y'),
(33, 20152, 213131, 86208, 'B.2015.1.1.032', '2016-02-07', 'Y'),
(34, 20152, 213131, 86208, 'B.2015.1.1.033', '2016-02-07', 'Y'),
(35, 20152, 213131, 86208, 'B.2015.1.1.034', '2016-02-07', 'Y'),
(36, 20152, 213131, 86208, 'B.2015.1.1.035', '2016-02-07', 'Y'),
(37, 20152, 213131, 86208, 'B.2015.1.1.036', '2016-02-07', 'Y'),
(38, 20152, 213131, 86208, 'B.2015.1.1.037', '2016-02-07', 'Y'),
(39, 20152, 213131, 86208, 'B.2015.1.1.038', '2016-02-07', 'Y'),
(44, 0, 100, 461, '2018210001', '2018-10-01', 'Y'),
(45, 0, 100, 461, '2018210002', '2018-10-01', 'Y'),
(46, 0, 100, 461, '2018210003', '2018-10-01', 'Y'),
(47, 2018, 100, 461, '2018210010', '2018-10-01', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruang`
--

CREATE TABLE IF NOT EXISTS `ruang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ruang_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Kampus_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Lantai` smallint(5) unsigned DEFAULT '1',
  `RuangKuliah` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'Y',
  `Kapasitas` int(10) unsigned DEFAULT '0',
  `KapasitasUjian` int(10) unsigned DEFAULT '0',
  `Keterangan` text COLLATE latin1_general_ci,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `Ruang_ID` (`Ruang_ID`),
  KEY `Kampus_ID` (`Kampus_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=20 ;

--
-- Dumping data untuk tabel `ruang`
--

INSERT INTO `ruang` (`ID`, `Ruang_ID`, `Nama`, `Kampus_ID`, `Lantai`, `RuangKuliah`, `Kapasitas`, `KapasitasUjian`, `Keterangan`, `Aktif`) VALUES
(15, 'RA03', 'RUANG 3', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(4, 'RA01', 'RUANG 1', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(14, 'RA02', 'RUANG 2', 'K1', 1, 'Y', 40, 30, '', 'Y'),
(13, 'RA05', 'RUANG 5', 'K1', 1, 'Y', 40, 30, '', 'Y'),
(16, 'RA06', 'RUANG 6', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(17, 'RA04', 'RUANG 4', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(18, 'RA07', 'RUANG 7', 'K1', 1, 'Y', 40, 20, '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statusawal`
--

CREATE TABLE IF NOT EXISTS `statusawal` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `StatusAwal_ID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `BeliFormulir` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `JalurKhusus` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `TanpaTest` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Catatan` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `statusawal`
--

INSERT INTO `statusawal` (`ID`, `StatusAwal_ID`, `Nama`, `BeliFormulir`, `JalurKhusus`, `TanpaTest`, `Catatan`, `Aktif`) VALUES
(1, 'P', 'Pindahan', 'Y', 'N', 'Y', '', 'Y'),
(2, 'B', 'Baru', 'Y', 'N', 'N', NULL, 'Y'),
(3, 'S', 'PSSB', 'Y', 'Y', 'Y', 'Untuk siswa SMA berprestasi', 'Y'),
(4, 'D', 'Drop-in', 'Y', 'N', 'Y', '', 'Y'),
(5, 'A', 'Asing', 'Y', 'Y', 'Y', 'Untuk calon mahasiswa asing', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statuskerja`
--

CREATE TABLE IF NOT EXISTS `statuskerja` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `StatusKerja_ID` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `StatusKerja_ID` (`StatusKerja_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `statuskerja`
--

INSERT INTO `statuskerja` (`ID`, `StatusKerja_ID`, `Nama`, `Def`, `NA`) VALUES
(1, 'A', 'Dosen Tetap', 'N', 'N'),
(2, 'B', 'Dosen PNS Dipekerjakan', 'N', 'N'),
(3, 'C', 'Dosen Honorer PTN', 'N', 'N'),
(4, 'D', 'Dosen Honorer Non PTN', 'N', 'N'),
(5, 'E', 'Dosen Kontrak', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statusmhsw`
--

CREATE TABLE IF NOT EXISTS `statusmhsw` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `StatusMhsw_ID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nilai` smallint(6) NOT NULL DEFAULT '0',
  `Keluar` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `StatusMhsw_ID` (`StatusMhsw_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `statusmhsw`
--

INSERT INTO `statusmhsw` (`ID`, `StatusMhsw_ID`, `Nama`, `Nilai`, `Keluar`, `Def`, `Aktif`) VALUES
(1, 'A', 'Aktif', 1, 'N', 'N', 'N'),
(2, 'C', 'Cuti', 0, 'N', 'N', 'N'),
(3, 'P', 'Pasif', 1, 'N', 'Y', 'N'),
(4, 'K', 'Keluar', 0, 'Y', 'N', 'N'),
(5, 'D', 'Drop-out', 0, 'Y', 'N', 'N'),
(6, 'L', 'Lulus', 0, 'Y', 'N', 'N'),
(7, 'T', 'Tunggu Ujian', 1, 'N', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statusmtk`
--

CREATE TABLE IF NOT EXISTS `statusmtk` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `StatusMtk_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `StatusMtk_ID` (`StatusMtk_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `statusmtk`
--

INSERT INTO `statusmtk` (`ID`, `StatusMtk_ID`, `Nama`, `Aktif`) VALUES
(1, 'A', 'AKTIF', 'Y'),
(2, 'H', 'HAPUS', 'Y'),
(3, 'N', 'NON AKTIF', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statussipil`
--

CREATE TABLE IF NOT EXISTS `statussipil` (
  `ID` int(3) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `statussipil`
--

INSERT INTO `statussipil` (`ID`, `Nama`, `Aktif`) VALUES
(1, 'Belum Menikah', 'N'),
(2, 'Menikah', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tahun`
--

CREATE TABLE IF NOT EXISTS `tahun` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Tahun_ID` int(5) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Program_ID` int(1) NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `TglKRSMulai` date DEFAULT NULL,
  `TglKRSSelesai` date DEFAULT NULL,
  `TglCetakKHS` date NOT NULL DEFAULT '0000-00-00',
  `TglBayarMulai` date NOT NULL DEFAULT '0000-00-00',
  `TglBayarSelesai` date NOT NULL DEFAULT '0000-00-00',
  `TglKuliahMulai` date DEFAULT NULL,
  `TglKuliahSelesai` date DEFAULT NULL,
  `TglUTSMulai` date DEFAULT NULL,
  `TglUTSSelesai` date DEFAULT NULL,
  `TglUASMulai` date DEFAULT NULL,
  `TglUASSelesai` date DEFAULT NULL,
  `TglNilaiMulai` date NOT NULL,
  `TglNilaiSelesai` date NOT NULL,
  `HanyaAngkatan` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `TglBuat` datetime DEFAULT NULL,
  `LoginBuat` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `TglEdit` datetime DEFAULT NULL,
  `LoginEdit` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Catatan` text COLLATE latin1_general_ci,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `Tahun_ID` (`Tahun_ID`),
  KEY `Identitas_ID` (`Identitas_ID`),
  KEY `Jurusan_ID` (`Jurusan_ID`),
  KEY `Program_ID` (`Program_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `tahun`
--

INSERT INTO `tahun` (`ID`, `Tahun_ID`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `TglKRSMulai`, `TglKRSSelesai`, `TglCetakKHS`, `TglBayarMulai`, `TglBayarSelesai`, `TglKuliahMulai`, `TglKuliahSelesai`, `TglUTSMulai`, `TglUTSSelesai`, `TglUASMulai`, `TglUASSelesai`, `TglNilaiMulai`, `TglNilaiSelesai`, `HanyaAngkatan`, `TglBuat`, `LoginBuat`, `TglEdit`, `LoginEdit`, `Catatan`, `Aktif`) VALUES
(3, 20152, 213131, 86208, 3, 'Kalender Akademik Semester Genap 20152', '2016-02-22', '2016-02-27', '2016-07-12', '0000-00-00', '0000-00-00', '2016-02-29', '2016-06-19', '2016-04-18', '2016-04-24', '2016-06-27', '2016-07-03', '2016-07-04', '2016-07-11', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(4, 20152, 213131, 60202, 3, 'Kalender Akademik Semester Genap 20152', '2016-02-22', '2016-02-27', '2016-07-12', '0000-00-00', '0000-00-00', NULL, NULL, '2016-04-18', '2016-04-24', '2016-06-27', '2016-07-03', '2016-07-04', '2016-07-11', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(5, 20151, 213131, 60202, 3, 'semester gasal 20151', '2015-09-07', '2015-09-12', '2016-02-29', '0000-00-00', '0000-00-00', '2015-09-14', '2016-01-02', '2015-11-02', '2015-11-07', '2016-01-11', '2016-01-17', '2016-01-24', '2016-02-29', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(6, 2018, 100, 461, 3, 'KALENDER 2018', '2018-08-01', '2018-08-11', '2019-02-16', '0000-00-00', '0000-00-00', NULL, NULL, '2018-09-01', '2018-09-11', '2018-09-12', '2018-09-13', '2018-09-14', '2018-10-31', NULL, NULL, NULL, NULL, NULL, NULL, 'Y');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
