<?php
  header('location:media.php?page=home'); 
?>
